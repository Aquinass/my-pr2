/**
 * Batch rebranding engine.
 * All coordinates are expressed relative to a 612px-wide reference page
 * (US Letter at 72dpi, matching the source PNGs) and scaled to the actual
 * image size, so it works on any resolution export of the same layout.
 */

export type RebrandSettings = {
  brandUrl: string
  headerHeightPct: number // fraction of page height covered by old header (incl. the @url tag)
  footerHeightPct: number // fraction of page height covered by old footer
  replaceTipsTitle: boolean
  tipsTitle: string
  tipsTitleFind: string // the word(s) to strip from OCR'd title, e.g. "NCLEX"
  titleOverride?: string
}

export type ProcessedPage = {
  id: string
  fileName: string
  title: string
  ocrTitle: string
  originalUrl: string
  outputUrl: string | null
  outputBlob: Blob | null
  status: "queued" | "ocr" | "rendering" | "done" | "error"
  error?: string
  tipsBoxFound: boolean
}

export const DEFAULT_SETTINGS: RebrandSettings = {
  brandUrl: "WWW.CAMBRIDGENURSE.COM",
  headerHeightPct: 0.098, // ~78px of 792
  footerHeightPct: 0.045, // ~36px of 792
  replaceTipsTitle: true,
  tipsTitle: "Success Tips",
  tipsTitleFind: "NCLEX",
}

const REF_W = 612

/* ---------- colour helpers ---------- */

// Teal used by the "Success Tips" box in the source files (#00A79D)
const TEAL = { r: 0, g: 167, b: 157 }
function isTeal(r: number, g: number, b: number, tol = 22) {
  return (
    Math.abs(r - TEAL.r) < tol &&
    Math.abs(g - TEAL.g) < tol &&
    Math.abs(b - TEAL.b) < tol
  )
}

/**
 * Finds the top edge and horizontal extent of the teal tips box.
 * Scans rows; the first row where >35% of pixels are teal is the top.
 */
export function detectTealBox(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
) {
  const data = ctx.getImageData(0, 0, w, h).data
  let top = -1
  let left = w
  let right = 0
  const step = 2
  // skip the header zone entirely so its gradient can't be mistaken for the box
  const startY = Math.round(h * 0.12)
  for (let y = startY; y < h; y += step) {
    let count = 0
    let rowLeft = w
    let rowRight = 0
    for (let x = 0; x < w; x += step) {
      const i = (y * w + x) * 4
      if (isTeal(data[i], data[i + 1], data[i + 2])) {
        count++
        if (x < rowLeft) rowLeft = x
        if (x > rowRight) rowRight = x
      }
    }
    if (count / (w / step) > 0.35) {
      top = y
      left = rowLeft
      right = rowRight
      break
    }
  }
  if (top < 0) return null
  return { top, left, right }
}

/* ---------- drawing ---------- */

/* ---------- header geometry (all in 612px reference units) ---------- */

// The ribbon graphic in /templates/header-ribbon.png is 340x173. Inside it the
// horizontal bar occupies rows 54-130 and the diagonal ribbon shape ends at
// x≈318, so the last ~20px of the image are pure bar and can overlap the
// bar we draw across the rest of the page without a visible seam.
const RIBBON_SRC = "/templates/header-ribbon.png"
const RIBBON_NATIVE_W = 340
const RIBBON_NATIVE_H = 173
const RIBBON_BAR_TOP = 54
const RIBBON_BAR_BOTTOM = 130
const RIBBON_W = 200 // drawn width at reference scale
const RIBBON_K = RIBBON_W / RIBBON_NATIVE_W
const RIBBON_H = RIBBON_NATIVE_H * RIBBON_K // ≈102
const BAR_TOP = RIBBON_BAR_TOP * RIBBON_K // ≈32
const BAR_BOTTOM = RIBBON_BAR_BOTTOM * RIBBON_K // ≈76
const BAR_COLOR = "#0050cc"
const URL_BASELINE = RIBBON_H + 12 // ≈114, sits just under the ribbon
/** Total height the new header needs before page content may begin. */
export const HEADER_TOTAL_H = URL_BASELINE + 10
/** Fallback height of the old header (incl. its @url tag) if detection fails. */
const OLD_HEADER_H = 76

/**
 * Find where the source page's old header actually ends. The old header is
 * made of saturated / dark pixels (blue bar, dark @url pill), so we scan down
 * from the bar and return the first row that contains no dark pixels at all.
 * A light-grey section band directly under the header therefore counts as
 * content and is preserved instead of being sliced by the wipe.
 * Returns a y in source pixels; falls back to OLD_HEADER_H * s.
 */
function detectOldHeaderEnd(img: HTMLImageElement, s: number): number {
  const w = img.naturalWidth
  const scanTo = Math.min(img.naturalHeight, Math.round(140 * s))
  const c = document.createElement("canvas")
  c.width = w
  c.height = scanTo
  const cx = c.getContext("2d")!
  cx.drawImage(img, 0, 0)
  const d = cx.getImageData(0, 0, w, scanTo).data
  // fraction of pixels in the row that are "dark" (any channel below 200)
  const rowDark = (y: number) => {
    let n = 0
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4
      if (d[i] < 200 || d[i + 1] < 200 || d[i + 2] < 200) n++
    }
    return n / w
  }
  const start = Math.round(48 * s) // just below the old blue bar
  const needLight = Math.max(2, Math.round(2 * s))
  let lightRun = 0
  for (let y = start; y < scanTo; y++) {
    if (rowDark(y) < 0.003) {
      lightRun++
      if (lightRun >= needLight) return y - needLight + 1
    } else {
      lightRun = 0
    }
  }
  return Math.round(OLD_HEADER_H * s)
}

let ribbonPromise: Promise<HTMLImageElement> | null = null
function getRibbon() {
  if (!ribbonPromise) ribbonPromise = loadImage(RIBBON_SRC)
  return ribbonPromise
}

/** Greedy word-wrap; shrinks the font until the text fits in `maxLines`. */
function fitLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines: number,
  startPx: number,
  minPx: number,
  fontFamily: string,
) {
  const words = text.split(/\s+/).filter(Boolean)
  for (let px = startPx; px >= minPx; px -= 0.5) {
    ctx.font = `bold ${px}px ${fontFamily}`
    const lines: string[] = []
    let cur = ""
    let tooLong = false
    for (const word of words) {
      const next = cur ? `${cur} ${word}` : word
      if (ctx.measureText(next).width <= maxWidth) {
        cur = next
      } else {
        if (!cur || ctx.measureText(word).width > maxWidth) {
          tooLong = true
          break
        }
        lines.push(cur)
        cur = word
      }
    }
    if (cur) lines.push(cur)
    if (!tooLong && lines.length <= maxLines) return { lines, px }
  }
  ctx.font = `bold ${minPx}px ${fontFamily}`
  return { lines: [text], px: minPx }
}

function drawHeader(
  ctx: CanvasRenderingContext2D,
  w: number,
  s: number,
  title: string,
  brandUrl: string,
  ribbon: HTMLImageElement,
  oldHeaderEnd: number,
  pad = 0,
) {
  // wipe exactly the old header (now shifted down by `pad`) plus the new
  // header zone — never past the first blank gap, so no content gets clipped
  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, w, Math.max(oldHeaderEnd + pad, HEADER_TOTAL_H * s))

  const barTop = BAR_TOP * s
  const barBottom = BAR_BOTTOM * s
  const barH = barBottom - barTop
  const ribW = RIBBON_W * s
  const ribH = RIBBON_H * s

  // full-width bar, then the ribbon graphic on top of its left end
  ctx.fillStyle = BAR_COLOR
  ctx.fillRect(ribW - 12 * s, barTop, w - ribW + 12 * s, barH)
  ctx.drawImage(ribbon, 0, 0, ribW, ribH)

  // title: left-aligned beside the ribbon, wrapped to at most 2 lines
  const textX = ribW + 10 * s
  const maxWidth = w - textX - 12 * s
  const { lines, px } = fitLines(
    ctx,
    title.toUpperCase(),
    maxWidth,
    2,
    15 * s,
    9 * s,
    "Arial, Helvetica, sans-serif",
  )
  const lineH = px * 1.15
  const blockH = lineH * lines.length
  ctx.fillStyle = "#ffffff"
  ctx.textAlign = "left"
  ctx.textBaseline = "middle"
  lines.forEach((line, i) => {
    ctx.fillText(line, textX, barTop + barH / 2 - blockH / 2 + lineH * (i + 0.5))
  })

  // url line under the bar, right-aligned
  ctx.fillStyle = "#111111"
  ctx.font = `bold ${13 * s}px Arial, Helvetica, sans-serif`
  ctx.textAlign = "right"
  ctx.textBaseline = "alphabetic"
  ctx.fillText(brandUrl.toUpperCase(), w - 10 * s, URL_BASELINE * s)
}

function drawFooter(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  s: number,
  brandUrl: string,
  footerPct: number,
) {
  const footerH = Math.max(h * footerPct, 24 * s)
  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, h - footerH, w, footerH)
  ctx.fillStyle = "#222222"
  ctx.font = `bold ${9 * s}px Arial, Helvetica, sans-serif`
  ctx.textAlign = "right"
  ctx.textBaseline = "alphabetic"
  ctx.fillText(brandUrl.toUpperCase(), w - 10 * s, h - 12 * s)
}

function drawTipsTitle(
  ctx: CanvasRenderingContext2D,
  s: number,
  box: { top: number; left: number; right: number },
  title: string,
) {
  // The title band sits in the first ~30px (ref scale) of the box.
  // Leave room for the pushpins at both ends.
  const bandTop = box.top + 2 * s
  const bandH = 28 * s
  const inset = 55 * s
  ctx.fillStyle = `rgb(${TEAL.r},${TEAL.g},${TEAL.b})`
  ctx.fillRect(box.left + inset, bandTop, box.right - box.left - inset * 2, bandH)

  const cx = (box.left + box.right) / 2
  const cy = bandTop + bandH / 2 + 2 * s
  ctx.fillStyle = "#ffffff"
  ctx.font = `bold ${16 * s}px "Comic Sans MS", "Comic Neue", cursive, sans-serif`
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText(title, cx, cy)
  const tw = ctx.measureText(title).width
  ctx.fillRect(cx - tw / 2, cy + 10 * s, tw, 1.5 * s)
}

/* ---------- OCR ---------- */

let workerPromise: Promise<import("tesseract.js").Worker> | null = null
async function getWorker() {
  if (!workerPromise) {
    workerPromise = (async () => {
      const { createWorker } = await import("tesseract.js")
      return createWorker("eng")
    })()
  }
  return workerPromise
}

/** OCR the right half of the old header where the page title lives. */
export async function ocrHeaderTitle(img: HTMLImageElement): Promise<string> {
  const s = img.naturalWidth / REF_W
  const crop = document.createElement("canvas")
  // Title sits in the right ~45% of the header, between y≈18 and y≈50 (ref px)
  const cw = Math.round(img.naturalWidth * 0.45)
  const cy = Math.round(18 * s)
  const ch = Math.round(34 * s)
  // upscale 3x for better OCR on small text
  crop.width = cw * 3
  crop.height = ch * 3
  const cctx = crop.getContext("2d")!
  cctx.drawImage(img, img.naturalWidth - cw, cy, cw, ch, 0, 0, crop.width, crop.height)
  // invert so white-on-teal becomes dark-on-light
  const d = cctx.getImageData(0, 0, crop.width, crop.height)
  for (let i = 0; i < d.data.length; i += 4) {
    const lum = 0.299 * d.data[i] + 0.587 * d.data[i + 1] + 0.114 * d.data[i + 2]
    const v = lum > 200 ? 0 : 255
    d.data[i] = d.data[i + 1] = d.data[i + 2] = v
  }
  cctx.putImageData(d, 0, 0)
  const worker = await getWorker()
  const {
    data: { text },
  } = await worker.recognize(crop)
  return text
    .replace(/[^A-Za-z0-9 &'()/-]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    // drop leading junk tokens like "EE" / "|" picked up from the logo edge
    .replace(/^(?:[A-Za-z]{1,2}\s+)+(?=[A-Za-z]{3,})/, "")
    .trim()
}

/* ---------- main ---------- */

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error("Could not load image"))
    img.src = src
  })
}

export async function renderRebrand(
  img: HTMLImageElement,
  title: string,
  settings: RebrandSettings,
): Promise<{ blob: Blob; tipsBoxFound: boolean }> {
  const w = img.naturalWidth
  const s = w / REF_W
  const ribbon = await getRibbon()
  // Detect where the old header (incl. its @url tag) really ends, then shift
  // the page down just enough that the new header (bar + url line) finishes
  // above that point.
  const oldHeaderEnd = detectOldHeaderEnd(img, s)
  const pad = Math.max(0, Math.round(HEADER_TOTAL_H * s - oldHeaderEnd))
  const h = img.naturalHeight + pad
  const canvas = document.createElement("canvas")
  canvas.width = w
  canvas.height = h
  const ctx = canvas.getContext("2d")!
  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, w, h)
  ctx.drawImage(img, 0, pad)

  let tipsBoxFound = false
  if (settings.replaceTipsTitle) {
    const box = detectTealBox(ctx, w, h)
    if (box) {
      tipsBoxFound = true
      drawTipsTitle(ctx, s, box, settings.tipsTitle)
    }
  }

  drawHeader(ctx, w, s, title, settings.brandUrl, ribbon, oldHeaderEnd, pad)
  drawFooter(ctx, w, h, s, settings.brandUrl, settings.footerHeightPct)

  const blob = await new Promise<Blob>((res, rej) =>
    canvas.toBlob((b) => (b ? res(b) : rej(new Error("toBlob failed"))), "image/png"),
  )
  return { blob, tipsBoxFound }
}

export function titleFromFileName(name: string) {
  return name
    .replace(/\.[^.]+$/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\d+\s*$/, "")
    .trim()
}
